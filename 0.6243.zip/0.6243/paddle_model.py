import paddle
from paddle import nn
import paddle.nn.functional as F
from paddlenlp.transformers import BertModel
from category_id_map import CATEGORY_ID_LIST


class MultiModal(nn.Layer):
    def __init__(self, args):
        super(MultiModal, self).__init__()
        self.bert = BertModel.from_pretrained(args.bert_dir)
        self.nextvlad = NeXtVLAD(args.frame_embedding_size, args.vlad_cluster_size,
                                 output_size=args.vlad_hidden_size, dropout=args.dropout)
        self.enhance = SENet(channels=args.vlad_hidden_size, ratio=args.se_ratio)
        bert_output_size = 768
        self.fusion = ConcatDenseSE(args.vlad_hidden_size + bert_output_size, args.fc_size, args.se_ratio, args.dropout)
        self.classifier = nn.Linear(args.fc_size, len(CATEGORY_ID_LIST))

    def forward(self, inputs, inference=False):

        # tuple 0:frame_input 1:frame_mask 2:title_input 3:title_mask 4:label
        # return 0:sequence_output 1:pooled_output

        bert_embedding = self.bert(inputs['title_input'], inputs['title_mask'])[1]
        vision_embedding = self.nextvlad(inputs['frame_input'], inputs['frame_mask'])
        vision_embedding = self.enhance(vision_embedding)
        final_embedding = self.fusion([vision_embedding, bert_embedding])
        prediction = self.classifier(final_embedding)
        if inference:
            return paddle.argmax(prediction, axis=1)
        else:
            return self.cal_loss(prediction, inputs['label'])

    @staticmethod
    def cal_loss(prediction, label):
        label = paddle.squeeze(label, axis=1)
        loss = F.cross_entropy(prediction, label)
        with paddle.no_grad():
            pred_label_id = paddle.argmax(prediction, axis=1)
            accuracy = (label == pred_label_id).sum() / label.shape[0]
        return loss, accuracy, pred_label_id, label


class NeXtVLAD(nn.Layer):
    def __init__(self, feature_size, cluster_size, output_size=1024, expansion=2, groups=8, dropout=0.2):
        super(NeXtVLAD, self).__init__()
        self.feature_size = feature_size
        self.output_size = output_size
        self.expansion_size = expansion
        self.cluster_size = cluster_size
        self.groups = groups
        self.drop_rate = dropout
        self.sigmoid = nn.Sigmoid()
        self.softmax = nn.Softmax()
        self.new_feature_size = self.expansion_size * self.feature_size // self.groups

        self.dropout = nn.Dropout(self.drop_rate)
        self.expansion_linear = nn.Linear(self.feature_size, self.expansion_size * self.feature_size)
        self.group_attention = nn.Linear(self.expansion_size * self.feature_size, self.groups)
        self.cluster_linear = nn.Linear(self.expansion_size * self.feature_size, self.groups * self.cluster_size,
                                        bias_attr=False)
        self.tx = paddle.rand([1, self.new_feature_size, self.cluster_size], dtype='float32')
        self.cluster_weight = paddle.create_parameter(shape=self.tx.shape, dtype=str(self.tx.numpy().dtype),
                                                      default_initializer=paddle.nn.initializer.Normal(std=0.01))
        self.cluster_weight.stop_gradient = True
        self.fc = nn.Linear(self.new_feature_size * self.cluster_size, self.output_size)

    def forward(self, inputs, mask):
        # todo mask
        inputs = self.expansion_linear(inputs)
        attention = self.group_attention(inputs)
        attention = self.sigmoid(attention)
        attention = attention.reshape([-1, inputs.shape[1] * self.groups, 1])
        reshaped_input = inputs.reshape([-1, self.expansion_size * self.feature_size])
        activation = self.cluster_linear(reshaped_input)
        activation = activation.reshape([-1, inputs.shape[1] * self.groups, self.cluster_size])
        activation = self.softmax(activation)
        activation = activation * attention
        a_sum = activation.sum(-2, keepdim=True)
        a = a_sum * self.cluster_weight
        activation = activation.transpose([0, 2, 1])
        reshaped_input = inputs.reshape([-1, inputs.shape[1] * self.groups, self.new_feature_size])
        vlad = paddle.matmul(activation, reshaped_input)
        vlad = vlad.transpose([0, 2, 1])
        vlad = F.normalize(vlad - a, p=2, axis=1)
        vlad = vlad.reshape([-1, self.cluster_size * self.new_feature_size])
        vlad = self.dropout(vlad)
        vlad = self.fc(vlad)
        return vlad


class SENet(nn.Layer):
    def __init__(self, channels, ratio=8):
        super(SENet, self).__init__()
        self.sequeeze = nn.Linear(in_features=channels, out_features=channels // ratio, bias_attr=False)
        self.relu = nn.ReLU()
        self.excitation = nn.Linear(in_features=channels // ratio, out_features=channels, bias_attr=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        gates = self.sequeeze(x)
        gates = self.relu(gates)
        gates = self.excitation(gates)
        gates = self.sigmoid(gates)
        x = paddle.multiply(x, gates)
        return x


class ConcatDenseSE(nn.Layer):
    def __init__(self, multimodal_hidden_size, hidden_size, se_ratio, dropout):
        super(ConcatDenseSE, self).__init__()
        self.fusion = nn.Linear(multimodal_hidden_size, hidden_size)
        self.fusion_dropout = nn.Dropout(dropout)
        self.enhance = SENet(channels=hidden_size, ratio=se_ratio)

    def forward(self, inputs):
        embeddings = paddle.concat(inputs, axis=1)
        embeddings = self.fusion_dropout(embeddings)
        embedding = self.fusion(embeddings)
        embedding = self.enhance(embedding)

        return embedding
